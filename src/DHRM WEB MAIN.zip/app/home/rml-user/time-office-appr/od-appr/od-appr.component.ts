import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-od-appr',
  templateUrl: './od-appr.component.html',
  styleUrls: ['./od-appr.component.css']
})
export class OdApprComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
