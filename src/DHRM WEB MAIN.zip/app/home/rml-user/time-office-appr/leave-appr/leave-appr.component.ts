import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leave-appr',
  templateUrl: './leave-appr.component.html',
  styleUrls: ['./leave-appr.component.css']
})
export class LeaveApprComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
