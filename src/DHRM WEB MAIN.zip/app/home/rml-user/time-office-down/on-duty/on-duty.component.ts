import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-on-duty',
  templateUrl: './on-duty.component.html',
  styleUrls: ['./on-duty.component.css']
})
export class OnDutyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
