import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-od-status',
  templateUrl: './od-status.component.html',
  styleUrls: ['./od-status.component.css']
})
export class OdStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
