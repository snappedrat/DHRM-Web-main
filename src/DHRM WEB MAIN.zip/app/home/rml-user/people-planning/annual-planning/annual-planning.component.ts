import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-annual-planning',
  templateUrl: './annual-planning.component.html',
  styleUrls: ['./annual-planning.component.css']
})
export class AnnualPlanningComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
