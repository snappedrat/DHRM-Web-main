export const environment = {
  production: true,

  path: 'http://localhost:3000',
  path2:'http://localhost:5000',
  // path2:'http://14.99.10.243:3000'
};
