import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trainee-score-card',
  templateUrl: './trainee-score-card.component.html',
  styleUrls: ['./trainee-score-card.component.css']
})
export class TraineeScoreCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
