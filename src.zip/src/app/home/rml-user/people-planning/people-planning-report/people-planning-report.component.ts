import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-people-planning-report',
  templateUrl: './people-planning-report.component.html',
  styleUrls: ['./people-planning-report.component.css']
})
export class PeoplePlanningReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
