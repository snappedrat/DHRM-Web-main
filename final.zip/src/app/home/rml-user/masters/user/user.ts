export interface User {
  sno:number;
  company_code: number;
  company_name: string;
  active_status: string;
  created_on:string;
  desig_name: string;
  del_status: string;
}
