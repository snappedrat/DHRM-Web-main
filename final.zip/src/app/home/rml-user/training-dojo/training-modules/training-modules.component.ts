import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-training-modules',
  templateUrl: './training-modules.component.html',
  styleUrls: ['./training-modules.component.css']
})
export class TrainingModulesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
