import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-result-summary',
  templateUrl: './test-result-summary.component.html',
  styleUrls: ['./test-result-summary.component.css']
})
export class TestResultSummaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
