export const environment = {
  production: true,

  path: 'localhost:3000'
};
