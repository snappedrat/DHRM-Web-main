import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-evaluation',
  templateUrl: './test-evaluation.component.html',
  styleUrls: ['./test-evaluation.component.css']
})
export class TestEvaluationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
