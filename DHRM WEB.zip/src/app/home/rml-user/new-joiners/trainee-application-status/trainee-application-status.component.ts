import { Component, OnInit } from '@angular/core';
import {UntypedFormGroup,UntypedFormControl, UntypedFormBuilder} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-trainee-application-status',
  templateUrl: './trainee-application-status.component.html',
  styleUrls: ['./trainee-application-status.component.css']
})
export class TraineeApplicationStatusComponent implements OnInit {

form: any
filterinfo: any
  constructor(private fb : UntypedFormBuilder, private http: HttpClient) {
    this.form = this.fb.group({
      status:new UntypedFormControl(' '),
      fromdate: new UntypedFormControl(' '),
      todate: new UntypedFormControl(' '),

    });
   }
  ngOnInit(): void {
    this.form.controls['status'].setValue('pending')
    this.form.controls['fromdate'].setValue('2018-02-02')
    this.form.controls['todate'].setValue('2022-10-07')
    this.filter()
  }

filter()
{
  console.log(this.form.value)
  this.http
  .post('http://14.99.10.243:3000/filter', this.form.value)
  .subscribe({
    next: (response) =>{ console.log(response); this.filterinfo = response},
    error: (error) => console.log(error),
  });
}

}
